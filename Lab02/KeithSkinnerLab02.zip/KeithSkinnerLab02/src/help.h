//Keith Skinner
//Lab 02

#ifndef LAB02_HELP_H
#define LAB02_HELP_H

#define UNKNOWN_ARGUMENT "Unknown Argument: %s\n"
#define UNEXPECTED_ARGUMENTS "Unexpected number of arguments to program."
#define NOTHING_TO_DO "Nothing to do."
#define MORE_INFORMATION "Try 'sub -h' for more information."

char * getHelpMessage();

#endif //LAB02_HELP_H
